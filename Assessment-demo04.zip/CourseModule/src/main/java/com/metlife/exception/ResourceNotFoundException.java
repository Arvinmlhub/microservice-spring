package com.metlife.exception;

public class ResourceNotFoundException extends Throwable {

    ResourceNotFoundException(){

    }
}
